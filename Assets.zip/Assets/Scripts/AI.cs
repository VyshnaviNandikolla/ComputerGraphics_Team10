using UnityEngine;

public class AI : MonoBehaviour
{
    public GameObject enemyPrefab;
    public Transform[] spawnPoints;
    public Transform player;

    public int playerHealth;
    public int playerScore;

    void PlaceEnemies()
    {
        if (playerScore < 100)
        {
            // Place enemies closer to the player
            SpawnEnemyNearPlayer();
        }
        else if (playerScore > 100)
        {
            // Place enemies at harder spawn points
            SpawnEnemyAtDifficultLocation();
        }
        else
        {
            // Place enemies randomly
            SpawnEnemyRandomly();
        }
    }

    void SpawnEnemyNearPlayer()
    {
        Vector3 spawnPosition = player.position + new Vector3(5f, 0f, 0f);
        Instantiate(enemyPrefab, spawnPosition, Quaternion.identity);
    }

    void SpawnEnemyAtDifficultLocation()
    {
        Instantiate(enemyPrefab, spawnPoints[spawnPoints.Length - 1].position, Quaternion.identity);
    }

    void SpawnEnemyRandomly()
    {
        int randomIndex = Random.Range(0, spawnPoints.Length);
        Instantiate(enemyPrefab, spawnPoints[randomIndex].position, Quaternion.identity);
    }
}
