using UnityEngine;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    public static ScoreManager instance; // Singleton instance for easy access

    public int score = 5; // The player's score
    public Text ScoreText; // UI Text to display the score

    private void Awake()
    {
        // Ensure only one instance exists
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // Keep the ScoreManager across scenes
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        UpdateScoreUI(); // Update the score UI at the start
    }

    public void AddScore(int value)
    {
        score += value; // Add the value to the current score
        UpdateScoreUI(); // Update the score UI
    }

    public void ResetScore()
    {
        score = 0; // Reset score to 0
        UpdateScoreUI(); // Update the score UI
    }

    private void UpdateScoreUI()
    {
        if (ScoreText != null)
        {
            ScoreText.text = score.ToString(); // Update the UI
        }
    }
}
